function initMap() {
    // The location
    const Location = { lat: -25.344, lng: 131.036 }; // Replace with actual coordinates
    // The map
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 15,
        center: Location,
    });
    // The marker, positioned at the restaurant
    const marker = new google.maps.Marker({
        position: Location,
        map: map,
    });
}