<?php include 'update7.php'; ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <title>PG info</title>
    <style>
 body {
    font-family: Arial,sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    height: 200vh;
    background: white;
    border-radius: 5px;
    user-select: none;
}
a{
    margin-left: 20px;
}

header {
    background-color: gray;
    color:  rgb(93, 5, 5);
    height: 55px;
    width: 100%;
    text-align: center;
    margin-top: 4px;
}
header h1{
    margin-top: 10px;
}

.photo-container {
    margin-top: 20px;
    margin-left: 60px;
    display: flex;
    justify-content: space-between;
    height: 500px;
    width: 90%;
    align-self: center;
    background-color: transparent;
    border: 2px solid black;
    border-radius: 10px;
    backdrop-filter: blur(2px);
}

.photo-box {
    background-color: transparent;
    border: 5px;
    flex: 1;
    margin-right: 40px;
    justify-content: center;
}
.photo-box img{
    margin-right: 40px;
}

form {
    background-color: transparant;
    padding: 2rem;
    backdrop-filter: blur(5px);
    border: 2px solid black;
    border-radius: 5px;
    height: 90%;
    width: 900px;
    display: flex;
    flex-direction: column;
    align-self: center;
    margin-left: 12%;
    margin-top: 45px;
}form:hover{
background-color: aqua;
}

label {
    margin-bottom: 0.5rem;
}

input {
    margin-bottom: 1rem;
    padding: 0.5rem;
    border: 1px solid black;
    border-radius: 3px;
}

.buttons {
    display: flex;
    justify-content: space-evenly;
    margin-top: 30px;
}

button {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 3px;
    background-color: #4CAF50;
    color: white;
    cursor: pointer;
}

button[type="button"] {
    background-color: #2196F3;
}

.bg{
    height: 400px;
    width: 250px;
    width: 100%;
    height: 100%;
    background-color: blanchedalmond;
    margin-right: 1120px;
}
    </style>
</head>
<body>
    <header>
        <h1>PG Information</h1>
    </header>
    <main>
        <form action="update3.php" method="post" enctype="multipart/form-data">
            <label>Name:</label>
            <input type="text" id="name" name="name" value="<?php echo ($row['name']) ? $row['name'] : ''; ?>" required readonly>

            <label>Address:</label>
            <input type="text" id="adderss" name="address" value="<?php echo $row['address']; ?>" required readonly>
             
              <label>Description:</label>
             <textarea type="text" id="description" aria-rowspan="10" name="description" rows="10" required readonly><?php echo $row['description']; ?></textarea>
 
                <label>Image:</label> 
                <img src="<?php echo $row['image']; ?>" id="image" name="image" value="<?php echo $row['image']; ?>" required>
                <label><a href="rating.html">Rate</a></label>
              
            <div class="buttons">
                <button><a href="mapmess.html">Map</a></button>
                <button>Reviews and ratings</button>
            </div>
        </form>
    </main>
</body>
</html>